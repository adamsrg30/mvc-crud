<?php
      require "partials/header.php";
?>
      <?php require_once ROOT . "app/views/" . $view . ".php"; ?>

<?php
      require "partials/footer.php";
?>