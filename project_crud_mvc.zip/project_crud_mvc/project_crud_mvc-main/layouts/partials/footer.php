

			</article>
		
			<footer>
				<?= FOOTER; ?>
			</footer>
      </main>

</body>

</html>