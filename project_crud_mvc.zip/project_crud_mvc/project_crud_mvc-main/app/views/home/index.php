<!-- <?php echo $data['row_index']; ?> -->

<h2 class="judul-halaman">Home</h2>

<div class="info">Selamat datang, <strong>Adam Malik Siregar</strong></div>